package event;
/**
 * Enum of the different choice that a player can use
 *
 */
public enum TypeChoice {
	
	/* The Choice enumeration */
	FORGE, EXPLOIT, NOTHING
}
