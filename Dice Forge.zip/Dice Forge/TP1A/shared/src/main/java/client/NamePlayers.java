package client;

 
/**
 * The Enum NamePlayers represents all possibles Names in a Game.
 */
public enum NamePlayers {
	
/** The list of possibles Names in the Game. */
 INGRID, 
 CORENTIN, 
 ARMAND, 
 MARC, 
 PIERRE;
}
